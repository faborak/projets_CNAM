package com.yaps.petstore;

public class CustomerFinderException extends CustomerException {

	public CustomerFinderException() {
		// TODO Auto-generated constructor stub
	}

}
