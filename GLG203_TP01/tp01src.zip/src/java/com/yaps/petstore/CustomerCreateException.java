package com.yaps.petstore;

public class CustomerCreateException extends CustomerException {

}
