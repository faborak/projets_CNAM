package com.yaps.petstore;

public class CustomerUpdateException extends CustomerException {

}
