package com.yaps.petstore;

public class CustomerRemoveException extends CustomerException {

}
