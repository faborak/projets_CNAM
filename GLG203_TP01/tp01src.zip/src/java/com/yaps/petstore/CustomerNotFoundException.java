package com.yaps.petstore;

public class CustomerNotFoundException extends CustomerFinderException {

	public CustomerNotFoundException() {
	}

}
