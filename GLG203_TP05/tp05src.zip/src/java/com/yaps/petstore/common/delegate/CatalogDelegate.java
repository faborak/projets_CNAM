package com.yaps.petstore.common.delegate;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Collection;

import com.yaps.petstore.common.dto.CategoryDTO;
import com.yaps.petstore.common.dto.CustomerDTO;
import com.yaps.petstore.common.dto.ItemDTO;
import com.yaps.petstore.common.dto.ProductDTO;
import com.yaps.petstore.common.exception.CheckException;
import com.yaps.petstore.common.exception.CreateException;
import com.yaps.petstore.common.exception.FinderException;
import com.yaps.petstore.common.exception.RemoveException;
import com.yaps.petstore.common.exception.UpdateException;
import com.yaps.petstore.common.rmi.RMIConstant;
import com.yaps.petstore.server.service.catalog.CatalogServiceRemote;

public class CatalogDelegate implements RMIConstant {

    // ======================================
    // =             Attributes             =
    // ======================================
    private static CatalogServiceRemote catalogServiceRemote;
	
    // ======================================
    // =           Business methods         =
    // ======================================

    /**
     * Delegates the call to the {@link CategoryServiceRemote#createCategory(CategoryDTO) CategoryServiceRemote().createCategory} method.
     */
	public static CategoryDTO createCategory(final CategoryDTO categoryDTO) throws CreateException, CheckException, RemoteException {
		return getCatalogService().createCategory(categoryDTO);
	}
	
	 /**
     * Delegates the call to the {@link CategoryServiceRemote#findCategory(String) CategoryServiceRemote().findCategory} method.
     */
	public static CategoryDTO findCategory(final String categoryId) throws FinderException, CheckException, RemoteException {
		return getCatalogService().findCategory(categoryId);
	}
	
	/**
     * Delegates the call to the {@link CategoryServiceRemote#deleteCategory(String) CategoryServiceRemote().deleteCategory} method.
     */
	public static void deleteCategory(final String categoryId) throws RemoveException, CheckException, RemoteException {
		getCatalogService().deleteCategory(categoryId);
	}
	
    /**
     * Delegates the call to the {@link CategoryServiceRemote#updateCategory(String) CategoryServiceRemote().updateCategory} method.
     */
	public static void updateCategory(final CategoryDTO categoryDTO) throws UpdateException, CheckException, RemoteException {
		getCatalogService().updateCategory(categoryDTO);
	}
	
    /**
     * Delegates the call to the {@link CategoryServiceRemote#findCategorys(String) CategoryServiceRemote().findCategorys} method.
     */	
	public static Collection findCategories() throws FinderException, RemoteException {
		return (Collection) getCatalogService().findCategories();
	}
	
    /**
     * Delegates the call to the {@link ProductServiceRemote#createProduct(ProductDTO) ProductServiceRemote().createProduct} method.
     */
	public static ProductDTO createProduct(final ProductDTO productDTO) throws CreateException, CheckException, RemoteException {
		return getCatalogService().createProduct(productDTO);
	}
	
	 /**
     * Delegates the call to the {@link ProductServiceRemote#findProduct(String) ProductServiceRemote().findProduct} method.
     */
	public static ProductDTO findProduct(String productId) throws FinderException, CheckException, RemoteException {
		return getCatalogService().findProduct(productId);
	}
	
	/**
     * Delegates the call to the {@link ProductServiceRemote#deleteProduct(String) ProductServiceRemote().deleteProduct} method.
     */
	public static void deleteProduct(final String productId) throws RemoveException, CheckException, RemoteException {
		getCatalogService().deleteProduct(productId);
	}
	
	/**
     * Delegates the call to the {@link ProductServiceRemote#deleteProduct(String) ProductServiceRemote().deleteProduct} method.
     */
	public static void updateProduct(final ProductDTO productDTO) throws UpdateException, CheckException, RemoteException  {
		getCatalogService().updateProduct(productDTO);
	}
	
    /**
     * Delegates the call to the {@link ProductServiceRemote#findProducts(String) ProductServiceRemote().findProducts} method.
     */	
	public static Collection findProducts() throws FinderException, RemoteException {
		return (Collection) getCatalogService().findProducts();
	}

    /**
     * Delegates the call to the {@link ItemServiceRemote#createItem(ItemDTO) ItemServiceRemote().createItem} method.
     */
	public static ItemDTO createItem(final ItemDTO itemDTO) throws CreateException, CheckException, RemoteException  {
		return getCatalogService().createItem(itemDTO);
	}
	
	 /**
     * Delegates the call to the {@link ItemServiceRemote#findItem(String) ItemServiceRemote().findItem} method.
     */
	public static ItemDTO findItem(final String ItemId) throws FinderException, CheckException, RemoteException {
		return getCatalogService().findItem(ItemId);
	}
	
	/**
     * Delegates the call to the {@link ItemServiceRemote#deleteItem(String) ItemServiceRemote().deleteItem} method.
     */
	public static void deleteItem(final String ItemId) throws RemoveException, CheckException, RemoteException{
		getCatalogService().deleteItem(ItemId);
	}
	
	/**
     * Delegates the call to the {@link ItemServiceRemote#deleteItem(String) ItemServiceRemote().deleteItem} method.
     */
	public static void updateItem(final ItemDTO itemDTO) throws UpdateException, CheckException, RemoteException {
		getCatalogService().updateItem(itemDTO);
	}

	 /**
     * Delegates the call to the {@link ItemServiceRemote#findItems(String) ItemServiceRemote().findItems} method.
     */	
	public static Collection findItems() throws FinderException, RemoteException {
		return (Collection) getCatalogService().findItems();
	}
	
    // ======================================
    // =            Private methods         =
    // ======================================
    private static CatalogServiceRemote getCatalogService() throws RemoteException {
        try {
        	catalogServiceRemote = (CatalogServiceRemote) Naming.lookup(CATALOG_SERVICE_URL);
        } catch (Exception e) {
            throw new RemoteException("Lookup exception", e);
        }
        return catalogServiceRemote;
    }
}
